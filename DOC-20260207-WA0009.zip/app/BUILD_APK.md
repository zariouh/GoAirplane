# Build APK Instructions

This document explains how to build the Android APK for the Airplane Mode Scheduler app.

## Prerequisites

1. **Node.js 18+** and **npm**
2. **Java JDK 17** (OpenJDK recommended)
3. **Android Studio** or **Android SDK Command Line Tools**

## Quick Build Steps

### Option 1: Using Android Studio (Recommended)

1. Open Android Studio
2. Select "Open an existing Android Studio project"
3. Navigate to the `android` folder in this project
4. Wait for Gradle sync to complete
5. Go to **Build > Build Bundle(s) / APK(s) > Build APK(s)**
6. The APK will be generated at:
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```

### Option 2: Using Command Line

1. Install Android SDK and set environment variables:
   ```bash
   export ANDROID_HOME=$HOME/Android/Sdk
   export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools
   ```

2. Make gradlew executable:
   ```bash
   cd android
   chmod +x gradlew
   ```

3. Build the debug APK:
   ```bash
   ./gradlew assembleDebug
   ```

4. The APK will be at:
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```

## Full Setup from Scratch

If you need to set up the entire project:

```bash
# 1. Install dependencies
npm install

# 2. Build the web app
npm run build

# 3. Sync with Capacitor
npx cap sync android

# 4. Open in Android Studio or build via command line
npx cap open android
```

## Project Structure

```
app/
├── android/              # Native Android project
│   ├── app/             # App module
│   │   ├── src/         # Source code
│   │   └── build.gradle # App build configuration
│   ├── build.gradle     # Project build configuration
│   └── gradle/          # Gradle wrapper
├── dist/                # Built web assets
├── src/                 # React source code
├── capacitor.config.ts  # Capacitor configuration
└── package.json         # Node dependencies
```

## Release Build

For a signed release APK:

1. Generate a keystore:
   ```bash
   keytool -genkey -v -keystore my-release-key.keystore -alias alias_name -keyalg RSA -keysize 2048 -validity 10000
   ```

2. Place the keystore in `android/app/`

3. Update `android/app/build.gradle` with signing config

4. Build release:
   ```bash
   ./gradlew assembleRelease
   ```

## Troubleshooting

### Gradle Download Issues
If Gradle download fails, manually download from https://services.gradle.org/distributions/ and extract to `~/.gradle/wrapper/dists/`

### SDK Not Found
Ensure `ANDROID_HOME` environment variable is set correctly:
```bash
export ANDROID_HOME=/path/to/android/sdk
```

### Sync Issues
If Capacitor sync fails:
```bash
npx cap copy android  # Copy web assets only
```

## App Features

- Schedule airplane mode on/off times
- Quick sleep mode (bedtime/wake time)
- Repeat schedules daily, weekdays, weekends, or custom
- Enable/disable schedules without deleting
- Beautiful Material You design
- All data stored locally on device

## Permissions

The app requires the following Android permissions:
- `WRITE_SETTINGS` - To toggle airplane mode (requires special permission on Android 10+)
- `RECEIVE_BOOT_COMPLETED` - To restore schedules after reboot

Note: On Android 10+, toggling airplane mode programmatically requires either:
- Device owner/admin permission
- Root access
- User manual confirmation via notification

The app will guide users through enabling these permissions on first launch.

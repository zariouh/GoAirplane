export type DayOfWeek = 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri' | 'Sat' | 'Sun';

export type ScheduleAction = 'on' | 'off';

export interface Schedule {
  id: string;
  time: string;
  action: ScheduleAction;
  label: string;
  repeat: DayOfWeek[];
  enabled: boolean;
  createdAt: number;
}

export interface QuickSleepConfig {
  bedtime: string;
  wakeTime: string;
  enabled: boolean;
}

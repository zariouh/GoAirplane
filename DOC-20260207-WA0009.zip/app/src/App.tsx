import { useState, useCallback } from 'react';
import { Plus, History, Calendar, Home } from 'lucide-react';
import { Header } from './components/Header';
import { QuickSleepCard } from './components/QuickSleepCard';
import { ScheduleCard } from './components/ScheduleCard';
import { EmptyState } from './components/EmptyState';
import { AddScheduleSheet } from './components/AddScheduleSheet';
import { QuickSleepSheet } from './components/QuickSleepSheet';
import { Toast } from './components/Toast';
import { useSchedules } from './hooks/useSchedules';
import type { DayOfWeek, ScheduleAction } from './types/schedule';
import { cn } from './lib/utils';

function App() {
  const { 
    sortedSchedules, 
    isLoaded,
    addSchedule, 
    toggleSchedule, 
    deleteSchedule,
    addQuickSleep,
    getTodaysSchedules 
  } = useSchedules();

  const [addSheetOpen, setAddSheetOpen] = useState(false);
  const [quickSleepOpen, setQuickSleepOpen] = useState(false);
  const [toast, setToast] = useState({ isVisible: false, message: '' });
  const [activeTab, setActiveTab] = useState<'home' | 'history'>('home');

  // Show toast message
  const showToast = useCallback((message: string) => {
    setToast({ isVisible: true, message });
  }, []);

  const hideToast = useCallback(() => {
    setToast(prev => ({ ...prev, isVisible: false }));
  }, []);

  // Handle save schedule
  const handleSaveSchedule = useCallback((
    time: string,
    action: ScheduleAction,
    label: string,
    repeat: DayOfWeek[]
  ) => {
    addSchedule(time, action, label, repeat);
    showToast('Schedule saved');
  }, [addSchedule, showToast]);

  // Handle quick sleep save
  const handleSaveQuickSleep = useCallback((bedtime: string, wakeTime: string) => {
    addQuickSleep(bedtime, wakeTime);
    showToast('Sleep mode schedules added');
  }, [addQuickSleep, showToast]);

  // Handle delete with confirmation
  const handleDelete = useCallback((id: string) => {
    deleteSchedule(id);
    showToast('Schedule deleted');
  }, [deleteSchedule, showToast]);

  // Get today's schedules for display
  const todaysSchedules = getTodaysSchedules();

  // Loading state
  if (!isLoaded) {
    return (
      <div className="min-h-screen bg-[var(--bg)] flex items-center justify-center">
        <div className="w-8 h-8 border-3 border-[var(--indigo)] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--bg)] pb-24">
      {/* Header */}
      <Header />

      {/* Main Content */}
      <main className="px-5">
        {/* Quick Sleep Card */}
        <section className="mt-4">
          <QuickSleepCard onClick={() => setQuickSleepOpen(true)} />
        </section>

        {/* Upcoming Section */}
        <section className="mt-6">
          <div className="flex items-center justify-between">
            <h2 className="text-[18px] font-semibold text-[var(--text)]">
              {sortedSchedules.length > 0 ? 'Your Schedules' : 'Upcoming'}
            </h2>
            {sortedSchedules.length > 0 && (
              <span className="text-[13px] text-[var(--text-tertiary)]">
                {sortedSchedules.filter(s => s.enabled).length} active
              </span>
            )}
          </div>

          {/* Schedule List */}
          <div className="mt-3 space-y-3">
            {sortedSchedules.length > 0 ? (
              sortedSchedules.map((schedule, index) => (
                <ScheduleCard
                  key={schedule.id}
                  schedule={schedule}
                  onToggle={() => toggleSchedule(schedule.id)}
                  onDelete={() => handleDelete(schedule.id)}
                  index={index}
                />
              ))
            ) : (
              <EmptyState onAddClick={() => setAddSheetOpen(true)} />
            )}
          </div>
        </section>

        {/* Today's Schedule Summary (if there are schedules) */}
        {sortedSchedules.length > 0 && todaysSchedules.length > 0 && (
          <section className="mt-6">
            <h2 className="text-[18px] font-semibold text-[var(--text)]">
              Today&apos;s Timeline
            </h2>
            <div className="mt-3 bg-white rounded-[20px] border border-[var(--divider)] p-4">
              <div className="space-y-3">
                {todaysSchedules.slice(0, 3).map((schedule, idx) => (
                  <div 
                    key={schedule.id} 
                    className={cn(
                      'flex items-center gap-3',
                      idx !== todaysSchedules.slice(0, 3).length - 1 && 'pb-3 border-b border-[var(--divider)]'
                    )}
                  >
                    <div 
                      className={cn(
                        'w-2 h-2 rounded-full',
                        schedule.action === 'on' ? 'bg-[var(--indigo)]' : 'bg-[var(--peach)]'
                      )} 
                    />
                    <span className="text-[14px] font-medium text-[var(--text)] w-16">
                      {schedule.time}
                    </span>
                    <span className="text-[13px] text-[var(--text-secondary)] flex-1 truncate">
                      {schedule.label}
                    </span>
                    <span 
                      className={cn(
                        'text-[11px] px-2 py-0.5 rounded-full font-medium',
                        schedule.action === 'on' 
                          ? 'bg-[var(--indigo-light)] text-[var(--indigo)]' 
                          : 'bg-[var(--peach)]/30 text-[#5a3d1a]'
                      )}
                    >
                      {schedule.action === 'on' ? 'ON' : 'OFF'}
                    </span>
                  </div>
                ))}
                {todaysSchedules.length > 3 && (
                  <p className="text-[12px] text-[var(--text-tertiary)] text-center pt-1">
                    +{todaysSchedules.length - 3} more today
                  </p>
                )}
              </div>
            </div>
          </section>
        )}
      </main>

      {/* Floating Action Button */}
      <button
        onClick={() => setAddSheetOpen(true)}
        className="fixed right-5 bottom-24 w-14 h-14 rounded-2xl bg-[var(--indigo)] text-white shadow-xl flex items-center justify-center pressable z-40 hover:bg-[var(--indigo-dark)] transition-colors"
        aria-label="Add schedule"
      >
        <Plus className="w-7 h-7" />
      </button>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-[var(--divider)] px-6 py-3 pb-[max(12px,env(safe-area-inset-bottom))] z-30">
        <div className="flex items-center justify-around max-w-md mx-auto">
          <button
            onClick={() => setActiveTab('home')}
            className={cn(
              'flex flex-col items-center gap-1 px-4 py-1 rounded-xl transition-colors',
              activeTab === 'home' ? 'text-[var(--indigo)]' : 'text-[var(--text-tertiary)]'
            )}
          >
            <Home className={cn('w-5 h-5', activeTab === 'home' && 'fill-current')} />
            <span className="text-[11px] font-medium">Home</span>
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={cn(
              'flex flex-col items-center gap-1 px-4 py-1 rounded-xl transition-colors',
              activeTab === 'history' ? 'text-[var(--indigo)]' : 'text-[var(--text-tertiary)]'
            )}
          >
            <History className="w-5 h-5" />
            <span className="text-[11px] font-medium">History</span>
          </button>
          <button
            className="flex flex-col items-center gap-1 px-4 py-1 rounded-xl text-[var(--text-tertiary)]"
          >
            <Calendar className="w-5 h-5" />
            <span className="text-[11px] font-medium">Calendar</span>
          </button>
        </div>
      </nav>

      {/* Sheets */}
      <AddScheduleSheet
        open={addSheetOpen}
        onOpenChange={setAddSheetOpen}
        onSave={handleSaveSchedule}
      />

      <QuickSleepSheet
        open={quickSleepOpen}
        onOpenChange={setQuickSleepOpen}
        onSave={handleSaveQuickSleep}
      />

      {/* Toast */}
      <Toast
        message={toast.message}
        isVisible={toast.isVisible}
        onClose={hideToast}
      />
    </div>
  );
}

export default App;

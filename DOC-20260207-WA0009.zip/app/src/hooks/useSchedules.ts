import { useState, useEffect, useCallback } from 'react';
import type { Schedule, DayOfWeek, ScheduleAction } from '@/types/schedule';

const STORAGE_KEY = 'airplane_mode_schedules';

export function useSchedules() {
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load schedules from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setSchedules(parsed);
      } catch (e) {
        console.error('Failed to parse schedules:', e);
      }
    }
    setIsLoaded(true);
  }, []);

  // Save to localStorage whenever schedules change
  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(schedules));
    }
  }, [schedules, isLoaded]);

  const addSchedule = useCallback((
    time: string,
    action: ScheduleAction,
    label: string,
    repeat: DayOfWeek[]
  ) => {
    const newSchedule: Schedule = {
      id: Date.now().toString(),
      time,
      action,
      label: label || (action === 'on' ? 'Airplane On' : 'Airplane Off'),
      repeat,
      enabled: true,
      createdAt: Date.now(),
    };
    setSchedules(prev => [...prev, newSchedule]);
    return newSchedule;
  }, []);

  const updateSchedule = useCallback((id: string, updates: Partial<Schedule>) => {
    setSchedules(prev =>
      prev.map(schedule =>
        schedule.id === id ? { ...schedule, ...updates } : schedule
      )
    );
  }, []);

  const toggleSchedule = useCallback((id: string) => {
    setSchedules(prev =>
      prev.map(schedule =>
        schedule.id === id ? { ...schedule, enabled: !schedule.enabled } : schedule
      )
    );
  }, []);

  const deleteSchedule = useCallback((id: string) => {
    setSchedules(prev => prev.filter(schedule => schedule.id !== id));
  }, []);

  const addQuickSleep = useCallback((bedtime: string, wakeTime: string) => {
    const allDays: DayOfWeek[] = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    
    const onSchedule: Schedule = {
      id: `sleep-on-${Date.now()}`,
      time: bedtime,
      action: 'on',
      label: 'Bedtime',
      repeat: allDays,
      enabled: true,
      createdAt: Date.now(),
    };
    
    const offSchedule: Schedule = {
      id: `sleep-off-${Date.now()}`,
      time: wakeTime,
      action: 'off',
      label: 'Wake up',
      repeat: allDays,
      enabled: true,
      createdAt: Date.now(),
    };
    
    setSchedules(prev => [...prev, onSchedule, offSchedule]);
    return { onSchedule, offSchedule };
  }, []);

  // Get sorted schedules (by time)
  const sortedSchedules = schedules.sort((a, b) => a.time.localeCompare(b.time));

  // Get enabled schedules
  const enabledSchedules = schedules.filter(s => s.enabled);

  // Get today's schedules (for display purposes)
  const getTodaysSchedules = useCallback(() => {
    const today = new Date().getDay();
    const dayMap: Record<number, DayOfWeek> = {
      0: 'Sun', 1: 'Mon', 2: 'Tue', 3: 'Wed', 4: 'Thu', 5: 'Fri', 6: 'Sat'
    };
    const todayName = dayMap[today];
    
    return schedules.filter(s => 
      s.enabled && (s.repeat.length === 0 || s.repeat.includes(todayName))
    ).sort((a, b) => a.time.localeCompare(b.time));
  }, [schedules]);

  return {
    schedules,
    sortedSchedules,
    enabledSchedules,
    isLoaded,
    addSchedule,
    updateSchedule,
    toggleSchedule,
    deleteSchedule,
    addQuickSleep,
    getTodaysSchedules,
  };
}

import React from 'react';
import { ToggleSwitch } from './ToggleSwitch';
import { Plane, Trash2, Repeat } from 'lucide-react';
import type { Schedule } from '@/types/schedule';
import { cn } from '@/lib/utils';

// Custom PlaneOff icon since it's not in lucide-react
const PlaneOffIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    className={className} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round"
  >
    <path d="M2 12h20" />
    <path d="M13 2v20" />
    <path d="M21 12l-6-6" />
    <path d="M21 12l-6 6" />
    <path d="M13 2L9 6" />
    <path d="M13 22l-4-4" />
    <line x1="2" y1="2" x2="22" y2="22" />
  </svg>
);

interface ScheduleCardProps {
  schedule: Schedule;
  onToggle: () => void;
  onDelete: () => void;
  index?: number;
}

export const ScheduleCard: React.FC<ScheduleCardProps> = ({ 
  schedule, 
  onToggle, 
  onDelete,
  index = 0 
}) => {
  const isOn = schedule.action === 'on';
  const accentColor = isOn ? 'bg-[var(--indigo)]' : 'bg-[var(--peach)]';
  const actionText = isOn ? 'Turn ON' : 'Turn OFF';
  
  const formatRepeat = (repeat: string[]) => {
    if (repeat.length === 0) return 'Once';
    if (repeat.length === 7) return 'Every day';
    if (repeat.length === 5 && 
        repeat.includes('Mon') && repeat.includes('Tue') && 
        repeat.includes('Wed') && repeat.includes('Thu') && repeat.includes('Fri')) {
      return 'Weekdays';
    }
    if (repeat.length === 2 && repeat.includes('Sat') && repeat.includes('Sun')) {
      return 'Weekends';
    }
    return repeat.join(', ');
  };

  return (
    <div 
      className={cn(
        'relative bg-white rounded-[20px] border border-[var(--divider)] p-4 pressable animate-enter',
        `stagger-${(index % 5) + 1}`
      )}
    >
      {/* Left accent strip */}
      <div className={cn('absolute left-0 top-4 bottom-4 w-1 rounded-r', accentColor)} />
      
      <div className="pl-3 flex items-center justify-between">
        <div className="flex-1 min-w-0">
          {/* Time */}
          <div className="text-[20px] font-semibold tracking-tight text-[var(--text)]">
            {schedule.time}
          </div>
          
          {/* Label and action */}
          <div className="mt-1 flex items-center gap-2 text-[13px] text-[var(--text-secondary)]">
            {isOn ? (
              <Plane className="w-3.5 h-3.5" />
            ) : (
              <PlaneOffIcon className="w-3.5 h-3.5" />
            )}
            <span className="truncate">{schedule.label} • {actionText}</span>
          </div>
          
          {/* Repeat info */}
          <div className="mt-1 flex items-center gap-1.5 text-[12px] text-[var(--text-tertiary)]">
            <Repeat className="w-3 h-3" />
            <span>{formatRepeat(schedule.repeat)}</span>
          </div>
        </div>
        
        {/* Controls */}
        <div className="flex flex-col items-end gap-2 ml-4">
          <ToggleSwitch checked={schedule.enabled} onChange={onToggle} />
          <button
            onClick={(e) => {
              e.stopPropagation();
              onDelete();
            }}
            className="p-1.5 rounded-lg text-[var(--text-tertiary)] hover:text-[var(--status-off)] hover:bg-red-50 transition-colors"
            aria-label="Delete schedule"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { cn } from '@/lib/utils';

interface ToggleSwitchProps {
  checked: boolean;
  onChange: () => void;
  className?: string;
}

export const ToggleSwitch: React.FC<ToggleSwitchProps> = ({ 
  checked, 
  onChange,
  className 
}) => {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={(e) => {
        e.stopPropagation();
        onChange();
      }}
      className={cn(
        'relative w-[52px] h-8 rounded-full transition-colors duration-200 ease-out',
        checked ? 'bg-[var(--indigo)]' : 'bg-[var(--divider)]',
        className
      )}
    >
      <span
        className={cn(
          'absolute top-[3px] left-[3px] w-[26px] h-[26px] rounded-full bg-white shadow-md transition-transform duration-200',
          checked ? 'translate-x-5' : 'translate-x-0'
        )}
        style={{
          transitionTimingFunction: 'cubic-bezier(0.34, 1.56, 0.64, 1)'
        }}
      />
    </button>
  );
};

import React from 'react';
import { cn } from '@/lib/utils';
import type { DayOfWeek } from '@/types/schedule';

interface DayChipProps {
  day: DayOfWeek;
  label: string;
  selected: boolean;
  onClick: () => void;
}

export const DayChip: React.FC<DayChipProps> = ({ 
  day: _day, 
  label, 
  selected, 
  onClick 
}) => {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'w-9 h-9 rounded-full text-[12px] font-medium transition-all duration-150 pressable',
        'border-[1.5px]',
        selected 
          ? 'bg-[var(--indigo)] text-white border-[var(--indigo)]' 
          : 'bg-white text-[var(--text-secondary)] border-[var(--divider)] hover:border-[var(--indigo)]/30'
      )}
      style={{
        transform: selected ? 'scale(1)' : 'scale(1)',
      }}
      aria-pressed={selected}
    >
      {label}
    </button>
  );
};

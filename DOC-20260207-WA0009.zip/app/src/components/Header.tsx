import React from 'react';
import { Settings } from 'lucide-react';

interface HeaderProps {
  onSettingsClick?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onSettingsClick }) => {
  const today = new Date();
  const dateStr = today.toLocaleDateString('en-US', { 
    weekday: 'long', 
    month: 'short', 
    day: 'numeric' 
  });

  return (
    <header className="px-5 pt-6 pb-2">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-[28px] font-semibold tracking-tight text-[var(--text)]">
            Schedules
          </h1>
          <p className="text-[15px] text-[var(--text-secondary)] mt-1">
            {dateStr}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={onSettingsClick}
            className="w-10 h-10 rounded-full bg-white border border-[var(--divider)] flex items-center justify-center text-[var(--text-secondary)] hover:text-[var(--indigo)] hover:border-[var(--indigo)]/30 transition-colors"
            aria-label="Settings"
          >
            <Settings className="w-5 h-5" />
          </button>
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[var(--indigo)] to-[var(--lavender)] flex items-center justify-center text-white font-semibold text-sm">
            <PlaneIcon className="w-5 h-5" />
          </div>
        </div>
      </div>
    </header>
  );
};

const PlaneIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    className={className} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round"
  >
    <path d="M2 12h20" />
    <path d="M13 2v20" />
    <path d="M21 12l-6-6" />
    <path d="M21 12l-6 6" />
    <path d="M13 2L9 6" />
    <path d="M13 22l-4-4" />
  </svg>
);

import React, { useState, useCallback } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Moon, Sun, Clock, BedDouble, AlarmClock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface QuickSleepSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (bedtime: string, wakeTime: string) => void;
}

export const QuickSleepSheet: React.FC<QuickSleepSheetProps> = ({ 
  open, 
  onOpenChange,
  onSave 
}) => {
  const [bedtime, setBedtime] = useState('22:30');
  const [wakeTime, setWakeTime] = useState('07:00');

  const handleSave = useCallback(() => {
    onSave(bedtime, wakeTime);
    onOpenChange(false);
  }, [bedtime, wakeTime, onSave, onOpenChange]);

  const presets = [
    { name: 'Early Bird', bedtime: '21:00', wakeTime: '05:00' },
    { name: 'Standard', bedtime: '22:30', wakeTime: '07:00' },
    { name: 'Night Owl', bedtime: '00:00', wakeTime: '09:00' },
  ];

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent 
        side="bottom" 
        className="bg-white rounded-t-[24px] border-t-0 px-5 pb-8 pt-2"
      >
        {/* Handle bar */}
        <div className="w-10 h-1.5 rounded-full bg-[var(--divider)] mx-auto mb-4" />
        
        <SheetHeader className="text-left mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[var(--indigo)]/10 flex items-center justify-center">
              <Moon className="w-5 h-5 text-[var(--indigo)]" />
            </div>
            <div>
              <SheetTitle className="text-[20px] font-semibold text-[var(--text)]">
                Quick Sleep Mode
              </SheetTitle>
              <p className="text-[13px] text-[var(--text-secondary)]">
                Set bedtime and wake time in one tap
              </p>
            </div>
          </div>
        </SheetHeader>

        <div className="space-y-6">
          {/* Presets */}
          <div>
            <label className="block text-[13px] font-medium text-[var(--text-secondary)] mb-2">
              Quick Presets
            </label>
            <div className="flex gap-2">
              {presets.map((preset) => (
                <button
                  key={preset.name}
                  type="button"
                  onClick={() => {
                    setBedtime(preset.bedtime);
                    setWakeTime(preset.wakeTime);
                  }}
                  className={cn(
                    'flex-1 py-2 px-3 rounded-xl border text-[12px] font-medium transition-all pressable',
                    bedtime === preset.bedtime && wakeTime === preset.wakeTime
                      ? 'bg-[var(--indigo)] text-white border-[var(--indigo)]'
                      : 'bg-white text-[var(--text-secondary)] border-[var(--divider)] hover:border-[var(--indigo)]/30'
                  )}
                >
                  {preset.name}
                </button>
              ))}
            </div>
          </div>

          {/* Bedtime */}
          <div>
            <label className="block text-[13px] font-medium text-[var(--text-secondary)] mb-2">
              <span className="flex items-center gap-2">
                <BedDouble className="w-4 h-4" />
                Bedtime (Airplane ON)
              </span>
            </label>
            <div className="relative">
              <Clock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--text-tertiary)]" />
              <input
                type="time"
                value={bedtime}
                onChange={(e) => setBedtime(e.target.value)}
                className="w-full h-12 pl-12 pr-4 rounded-xl border border-[var(--divider)] bg-white text-[16px] text-[var(--text)] focus:outline-none focus:ring-2 focus:ring-[var(--indigo)]/20 focus:border-[var(--indigo)] transition-all"
              />
            </div>
            <p className="mt-1 text-[12px] text-[var(--text-tertiary)]">
              Airplane mode will turn ON at this time
            </p>
          </div>

          {/* Wake Time */}
          <div>
            <label className="block text-[13px] font-medium text-[var(--text-secondary)] mb-2">
              <span className="flex items-center gap-2">
                <AlarmClock className="w-4 h-4" />
                Wake Time (Airplane OFF)
              </span>
            </label>
            <div className="relative">
              <Sun className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--text-tertiary)]" />
              <input
                type="time"
                value={wakeTime}
                onChange={(e) => setWakeTime(e.target.value)}
                className="w-full h-12 pl-12 pr-4 rounded-xl border border-[var(--divider)] bg-white text-[16px] text-[var(--text)] focus:outline-none focus:ring-2 focus:ring-[var(--indigo)]/20 focus:border-[var(--indigo)] transition-all"
              />
            </div>
            <p className="mt-1 text-[12px] text-[var(--text-tertiary)]">
              Airplane mode will turn OFF at this time
            </p>
          </div>

          {/* Info Card */}
          <div className="bg-[var(--indigo-light)] rounded-xl p-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-[var(--indigo)]/10 flex items-center justify-center flex-shrink-0">
                <Moon className="w-4 h-4 text-[var(--indigo)]" />
              </div>
              <div>
                <p className="text-[13px] font-medium text-[var(--text)]">
                  Sleep-friendly scheduling
                </p>
                <p className="text-[12px] text-[var(--text-secondary)] mt-0.5">
                  This creates two schedules that repeat every day. You can edit or delete them later.
                </p>
              </div>
            </div>
          </div>

          {/* Buttons */}
          <div className="pt-2 space-y-3">
            <Button
              onClick={handleSave}
              className="w-full h-14 rounded-2xl bg-[var(--indigo)] hover:bg-[var(--indigo-dark)] text-white font-semibold text-[15px] pressable"
            >
              Set Sleep Mode
            </Button>
            <Button
              variant="ghost"
              onClick={() => onOpenChange(false)}
              className="w-full h-12 rounded-2xl bg-[var(--bg)] text-[var(--text-secondary)] font-medium text-[15px] hover:bg-[var(--divider)]"
            >
              Cancel
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};

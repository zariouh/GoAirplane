import React, { useEffect, useState } from 'react';
import { CheckCircle2 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ToastProps {
  message: string;
  isVisible: boolean;
  onClose: () => void;
  duration?: number;
}

export const Toast: React.FC<ToastProps> = ({ 
  message, 
  isVisible, 
  onClose,
  duration = 2000 
}) => {
  const [progress, setProgress] = useState(100);

  useEffect(() => {
    if (isVisible) {
      setProgress(100);
      const interval = setInterval(() => {
        setProgress(prev => Math.max(0, prev - (100 / (duration / 50))));
      }, 50);

      const timeout = setTimeout(() => {
        onClose();
      }, duration);

      return () => {
        clearInterval(interval);
        clearTimeout(timeout);
      };
    }
  }, [isVisible, duration, onClose]);

  return (
    <div
      className={cn(
        'fixed left-1/2 -translate-x-1/2 bottom-6 z-50 flex flex-col items-center transition-all duration-300',
        isVisible 
          ? 'opacity-100 translate-y-0' 
          : 'opacity-0 translate-y-4 pointer-events-none'
      )}
    >
      <div className="px-4 py-3 rounded-xl bg-[#111114] text-white shadow-lg flex items-center gap-3 min-w-[200px]">
        <CheckCircle2 className="w-5 h-5 text-[var(--status-on)]" />
        <span className="text-[14px] font-medium">{message}</span>
      </div>
      {/* Progress bar */}
      <div 
        className={cn(
          'w-full h-0.5 bg-[var(--status-on)]/30 rounded-full mt-1 transition-all',
          isVisible ? 'opacity-100' : 'opacity-0'
        )}
        style={{ width: `${progress}%` }}
      />
    </div>
  );
};

import React, { useState, useEffect, useCallback } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Plane, Clock } from 'lucide-react';
import { DayChip } from './DayChip';
import type { DayOfWeek, ScheduleAction } from '@/types/schedule';
import { cn } from '@/lib/utils';

// Custom PlaneOff icon since it's not in lucide-react
const PlaneOffIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg 
    className={className} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round"
  >
    <path d="M2 12h20" />
    <path d="M13 2v20" />
    <path d="M21 12l-6-6" />
    <path d="M21 12l-6 6" />
    <path d="M13 2L9 6" />
    <path d="M13 22l-4-4" />
    <line x1="2" y1="2" x2="22" y2="22" />
  </svg>
);

interface AddScheduleSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (time: string, action: ScheduleAction, label: string, repeat: DayOfWeek[]) => void;
}

const DAYS: { day: DayOfWeek; label: string }[] = [
  { day: 'Mon', label: 'M' },
  { day: 'Tue', label: 'T' },
  { day: 'Wed', label: 'W' },
  { day: 'Thu', label: 'T' },
  { day: 'Fri', label: 'F' },
  { day: 'Sat', label: 'S' },
  { day: 'Sun', label: 'S' },
];

export const AddScheduleSheet: React.FC<AddScheduleSheetProps> = ({ 
  open, 
  onOpenChange,
  onSave 
}) => {
  const [time, setTime] = useState('09:00');
  const [action, setAction] = useState<ScheduleAction>('on');
  const [label, setLabel] = useState('');
  const [selectedDays, setSelectedDays] = useState<Set<DayOfWeek>>(new Set());

  // Reset form when sheet opens
  useEffect(() => {
    if (open) {
      setTime('09:00');
      setAction('on');
      setLabel('');
      setSelectedDays(new Set());
    }
  }, [open]);

  const toggleDay = useCallback((day: DayOfWeek) => {
    setSelectedDays(prev => {
      const next = new Set(prev);
      if (next.has(day)) {
        next.delete(day);
      } else {
        next.add(day);
      }
      return next;
    });
  }, []);

  const handleSave = useCallback(() => {
    onSave(time, action, label, Array.from(selectedDays));
    onOpenChange(false);
  }, [time, action, label, selectedDays, onSave, onOpenChange]);

  const selectAllDays = useCallback(() => {
    setSelectedDays(new Set(DAYS.map(d => d.day)));
  }, []);

  const selectWeekdays = useCallback(() => {
    setSelectedDays(new Set(['Mon', 'Tue', 'Wed', 'Thu', 'Fri']));
  }, []);

  const selectWeekends = useCallback(() => {
    setSelectedDays(new Set(['Sat', 'Sun']));
  }, []);

  const clearDays = useCallback(() => {
    setSelectedDays(new Set());
  }, []);

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent 
        side="bottom" 
        className="bg-white rounded-t-[24px] border-t-0 px-5 pb-8 pt-2 max-h-[90vh] overflow-y-auto"
      >
        {/* Handle bar */}
        <div className="w-10 h-1.5 rounded-full bg-[var(--divider)] mx-auto mb-4" />
        
        <SheetHeader className="text-left mb-6">
          <SheetTitle className="text-[20px] font-semibold text-[var(--text)]">
            Add Schedule
          </SheetTitle>
          <p className="text-[13px] text-[var(--text-secondary)]">
            Create a rule to toggle Airplane Mode automatically.
          </p>
        </SheetHeader>

        <div className="space-y-6">
          {/* Time Input */}
          <div>
            <Label className="block text-[13px] font-medium text-[var(--text-secondary)] mb-2">
              Time
            </Label>
            <div className="relative">
              <Clock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--text-tertiary)]" />
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                required
                className="w-full h-12 pl-12 pr-4 rounded-xl border border-[var(--divider)] bg-white text-[16px] text-[var(--text)] focus:outline-none focus:ring-2 focus:ring-[var(--indigo)]/20 focus:border-[var(--indigo)] transition-all"
              />
            </div>
          </div>

          {/* Action Selection */}
          <div>
            <Label className="block text-[13px] font-medium text-[var(--text-secondary)] mb-2">
              Action
            </Label>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setAction('on')}
                className={cn(
                  'flex-1 h-12 rounded-xl border flex items-center justify-center gap-2 text-[14px] font-medium transition-all pressable',
                  action === 'on'
                    ? 'bg-[var(--indigo)] text-white border-[var(--indigo)]'
                    : 'bg-white text-[var(--text-secondary)] border-[var(--divider)] hover:border-[var(--indigo)]/30'
                )}
              >
                <Plane className="w-4 h-4" />
                Turn ON
              </button>
              <button
                type="button"
                onClick={() => setAction('off')}
                className={cn(
                  'flex-1 h-12 rounded-xl border flex items-center justify-center gap-2 text-[14px] font-medium transition-all pressable',
                  action === 'off'
                    ? 'bg-[var(--peach)] text-[#5a3d1a] border-[var(--peach)]'
                    : 'bg-white text-[var(--text-secondary)] border-[var(--divider)] hover:border-[var(--peach)]/50'
                )}
              >
                <PlaneOffIcon className="w-4 h-4" />
                Turn OFF
              </button>
            </div>
          </div>

          {/* Repeat Days */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label className="text-[13px] font-medium text-[var(--text-secondary)]">
                Repeat
              </Label>
              <div className="flex gap-1">
                <button 
                  type="button" 
                  onClick={selectAllDays}
                  className="text-[11px] px-2 py-1 rounded-full bg-[var(--indigo-light)] text-[var(--indigo)] font-medium"
                >
                  All
                </button>
                <button 
                  type="button" 
                  onClick={selectWeekdays}
                  className="text-[11px] px-2 py-1 rounded-full bg-[var(--indigo-light)] text-[var(--indigo)] font-medium"
                >
                  Mon-Fri
                </button>
                <button 
                  type="button" 
                  onClick={selectWeekends}
                  className="text-[11px] px-2 py-1 rounded-full bg-[var(--indigo-light)] text-[var(--indigo)] font-medium"
                >
                  Sat-Sun
                </button>
                <button 
                  type="button" 
                  onClick={clearDays}
                  className="text-[11px] px-2 py-1 rounded-full bg-[var(--divider)] text-[var(--text-tertiary)] font-medium"
                >
                  Once
                </button>
              </div>
            </div>
            <div className="flex gap-2 justify-between">
              {DAYS.map(({ day, label }) => (
                <DayChip
                  key={day}
                  day={day}
                  label={label}
                  selected={selectedDays.has(day)}
                  onClick={() => toggleDay(day)}
                />
              ))}
            </div>
          </div>

          {/* Label Input */}
          <div>
            <Label className="block text-[13px] font-medium text-[var(--text-secondary)] mb-2">
              Label (optional)
            </Label>
            <Input
              type="text"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              placeholder="e.g. Bedtime, Focus work, Flight"
              className="w-full h-12 px-4 rounded-xl border-[var(--divider)] bg-white text-[15px] placeholder:text-[var(--text-tertiary)] focus:ring-2 focus:ring-[var(--indigo)]/20 focus:border-[var(--indigo)]"
            />
          </div>

          {/* Buttons */}
          <div className="pt-2 space-y-3">
            <Button
              onClick={handleSave}
              className="w-full h-14 rounded-2xl bg-[var(--indigo)] hover:bg-[var(--indigo-dark)] text-white font-semibold text-[15px] pressable"
            >
              Save Schedule
            </Button>
            <Button
              variant="ghost"
              onClick={() => onOpenChange(false)}
              className="w-full h-12 rounded-2xl bg-[var(--bg)] text-[var(--text-secondary)] font-medium text-[15px] hover:bg-[var(--divider)]"
            >
              Cancel
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};

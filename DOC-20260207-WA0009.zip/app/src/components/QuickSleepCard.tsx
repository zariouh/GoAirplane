import React from 'react';
import { Moon, ArrowRight, Plane } from 'lucide-react';
import { cn } from '@/lib/utils';

interface QuickSleepCardProps {
  onClick: () => void;
}

export const QuickSleepCard: React.FC<QuickSleepCardProps> = ({ onClick }) => {
  return (
    <div 
      onClick={onClick}
      className={cn(
        'relative overflow-hidden rounded-[20px] bg-gradient-to-br from-[var(--indigo)] to-[#1b1dc9] text-white p-5 shadow-lg pressable animate-enter cursor-pointer'
      )}
    >
      {/* Background decoration */}
      <div className="absolute -right-6 -top-6 w-32 h-32 rounded-full bg-white/10" />
      <div className="absolute -left-4 -bottom-4 w-20 h-20 rounded-full bg-white/5" />
      
      <div className="relative">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm">
            <Moon className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <div className="text-[18px] font-semibold">Quick Sleep Mode</div>
            <div className="text-[13px] text-white/80">
              Set bedtime & wake time in one tap
            </div>
          </div>
          <ArrowRight className="w-5 h-5 text-white/60" />
        </div>
        
        <div className="mt-4 flex gap-2">
          <div className="px-3 py-2 rounded-xl bg-white/10 backdrop-blur-sm text-[12px] flex items-center gap-2">
            <Plane className="w-3.5 h-3.5" />
            ON at bedtime
          </div>
          <div className="px-3 py-2 rounded-xl bg-white/10 backdrop-blur-sm text-[12px] flex items-center gap-2">
            <Plane className="w-3.5 h-3.5 rotate-180" />
            OFF at wake time
          </div>
        </div>
      </div>
    </div>
  );
};

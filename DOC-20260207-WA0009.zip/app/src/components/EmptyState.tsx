import React from 'react';
import { CloudMoon, Plus } from 'lucide-react';

interface EmptyStateProps {
  onAddClick: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({ onAddClick }) => {
  return (
    <div className="flex flex-col items-center justify-center py-12 px-6 text-center animate-enter">
      {/* Illustration */}
      <div className="relative">
        <div className="w-28 h-28 rounded-full bg-gradient-to-br from-[var(--lavender)] to-[var(--indigo-light)] flex items-center justify-center">
          <CloudMoon className="w-14 h-14 text-[var(--indigo)]" />
        </div>
        {/* Decorative elements */}
        <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[var(--peach)]" />
        <div className="absolute bottom-2 -left-2 w-3 h-3 rounded-full bg-[var(--lavender)]" />
      </div>
      
      {/* Text */}
      <h3 className="mt-6 text-[18px] font-semibold text-[var(--text)]">
        No schedules yet
      </h3>
      <p className="mt-2 text-[14px] text-[var(--text-secondary)] max-w-[240px]">
        Create your first schedule to automatically toggle Airplane Mode for sleep or focus time.
      </p>
      
      {/* CTA Button */}
      <button
        onClick={onAddClick}
        className="mt-6 flex items-center gap-2 px-5 py-3 rounded-xl bg-[var(--indigo)] text-white font-medium text-[14px] pressable"
      >
        <Plus className="w-4 h-4" />
        Add Schedule
      </button>
    </div>
  );
};
